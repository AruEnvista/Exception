package com.landmarkgroup.api.returnpolicyenquiry;

import com.microsoft.azure.keyvault.KeyVaultClient;
import com.microsoft.azure.keyvault.spring.AzureKeyVaultCredential;
import com.microsoft.azure.keyvault.spring.KeyVaultEnvironmentPostProcessor;
import org.kie.api.KieServices;
import org.kie.api.cdi.KContainer;
import org.kie.api.cdi.KReleaseId;
import org.kie.api.runtime.KieContainer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;

@SpringBootApplication
public class ReturnPolicyEnquiryApplication {

	//@Value("${spring-data-mongodb-uri}")
	//private String connectionString;

	public static void main(String[] args) {
		SpringApplication.run(ReturnPolicyEnquiryApplication.class, args);
	}

	/*@GetMapping("get")
	public String get() {
		return connectionString;
	}*/


	/*public void run(String... varl) throws Exception {
		System.out.println(String.format("\nConnection String stored in Azure Key Vault:\n%s\n",connectionString));
	}*/

	@Bean
	@KContainer
	@KReleaseId(groupId = "com.landmarkgroup.api",artifactId = "return-policy-enquiry-rules", version = "0.0.3-SNAPSHOT")
	public KieContainer kieContainer() {
		return KieServices.Factory.get().getKieClasspathContainer();
	}



}
