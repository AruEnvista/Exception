package com.landmarkgroup.api.returnpolicyenquiry.repository;

import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.SalesOrderResponse;
//import com.microsoft.azure.spring.data.cosmosdb.repository.ReactiveCosmosRepository;
//import com.microsoft.azure.spring.data.documentdb.repository.DocumentDbRepository;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Mono;

public interface SalesOrderRepository extends ReactiveMongoRepository<SalesOrderResponse, String> {
    Mono<SalesOrderResponse> findByOrderNumber(String orderNumber);
}
