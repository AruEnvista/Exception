package com.landmarkgroup.api.returnpolicyenquiry.exception;

import org.springframework.http.HttpStatus;

public class CustomErrorResponse {

    int httpCode;
    String httpMessage;
    String moreInformation;


    public CustomErrorResponse(String httpMessage, String moreInformation,int httpCode) {
        super();
        this.httpMessage = httpMessage;
        this.moreInformation= moreInformation;
        this.httpCode = httpCode;
    }

    public int getHttpCode() {
        return httpCode;
    }

    public void setHttpCode(int errorCode) {
        this.httpCode = httpCode;
    }

    public String getHttpMsg() {
        return httpMessage;
    }

    public void setHttpMsg(String httpMsg) {
        this.httpMessage =httpMsg;
    }

    public String getMoreInformation() {
        return moreInformation;
    }

    public void setMoreInformation(String moreInformation) {
        this.moreInformation = moreInformation;
    }

}