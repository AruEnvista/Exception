package com.landmarkgroup.api.returnpolicyenquiry.service;

import java.net.URISyntaxException;

public interface ServiceCommandInterface {

    public Object Execute() throws URISyntaxException;
}
