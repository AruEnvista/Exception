package com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class ExternalOrderLines {
    @NonNull
    @JsonProperty("item_id")
    private String itemId;

    @JsonProperty("item_description")
    private String itemDescription;

    @JsonProperty("maximum_returnable_quantity")
    private Number maximumReturnableQuantity;

    @JsonProperty("is_returnable")
    private String isReturnable="N";

    @JsonProperty("with_in_return_window")
    private String withInReturnWindow="N";

    @JsonProperty("return_window_period")
    private Number returnWindowPeriod;

    @JsonProperty("ordered_quantity")
    private Number orderedQuantity;

    @JsonProperty("department_code")
    private String departmentCode;

    @JsonProperty("delivery_type")
    private String deliveryType;
}
