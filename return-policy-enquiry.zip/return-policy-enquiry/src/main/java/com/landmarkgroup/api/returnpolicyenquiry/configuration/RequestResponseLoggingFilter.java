package com.landmarkgroup.api.returnpolicyenquiry.configuration;

import com.landmarkgroup.api.returnpolicyenquiry.exception.BadRequestException;
import com.landmarkgroup.api.returnpolicyenquiry.exception.NotFoundException;
import com.landmarkgroup.api.returnpolicyenquiry.exception.UnauthorizedException;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

@Component
@Slf4j
public class RequestResponseLoggingFilter implements WebFilter {

    @Value("${spring.identifier.client_ids}")
    private String[] clientIdentifier;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        ServerHttpRequest httpRequest = exchange.getRequest();
        final String httpUrl = httpRequest.getPath().toString();
        final String clientId = httpRequest.getHeaders().getFirst("x-ibm-client-id");
        if(clientId.isEmpty ())
            throw new BadRequestException ( "Client id value is empty" ) ;
        else if (!Arrays.asList(clientIdentifier).contains(clientId)) {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().writeWith(Mono.error(new Exception (  )));
        }

        ServerHttpRequestDecorator loggingServerHttpRequestDecorator = new ServerHttpRequestDecorator(exchange.getRequest()) {
            String requestBody = "";

            @Override
            public Flux<DataBuffer> getBody() {
                String[] orderNo = httpUrl.split("/");
                return super.getBody().doOnNext(dataBuffer -> {
                    try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
                        Channels.newChannel(byteArrayOutputStream).write(dataBuffer.asByteBuffer().asReadOnlyBuffer());
                        requestBody = new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8);
                        log.warn("{} | {} |Request | {}", clientId, orderNo[3], requestBody);
                    } catch (IOException e) {
                        log.error("{} | {} | Request | {}", clientId, orderNo[3], requestBody);
                    }
                });
            }
        };
        ServerHttpResponseDecorator loggingServerHttpResponseDecorator = new ServerHttpResponseDecorator(exchange.getResponse()) {
            String responseBody = "";

            @Override
            public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {

                String[] orderNo = httpUrl.split("/");
                Mono<DataBuffer> buffer = Mono.from(body);
                return super.writeWith(buffer.doOnNext(dataBuffer -> {
                    try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
                        Channels.newChannel(byteArrayOutputStream).write(dataBuffer.asByteBuffer().asReadOnlyBuffer());
                        responseBody = new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8);
                        log.warn("{} | {} | Response | {}", clientId, orderNo[3], responseBody);
                    } catch (Exception e) {
                        log.error("{} | {} | Response | {}", clientId, orderNo[3], responseBody);
                    }
                }));
            }
        };
        return chain.filter(exchange.mutate().request(loggingServerHttpRequestDecorator).response(loggingServerHttpResponseDecorator).build());
    }
}